# Final Submission Checklist

- [ ] Replace the second member placeholder in the report with the full name and matric number.
- [ ] Import `database/schema.sql` and test all three demo roles.
- [ ] Capture final screenshots from your own browser after successful local testing.
- [ ] Add the final hosted website URL and GitHub repository URL to the report.
- [ ] Confirm the folder name matches `BASE_URL` in `config/config.php`.
- [ ] Upload the PDF report and website link to UTM e-Learning before the deadline.
- [ ] Upload the source code and website link to GitHub as required.
