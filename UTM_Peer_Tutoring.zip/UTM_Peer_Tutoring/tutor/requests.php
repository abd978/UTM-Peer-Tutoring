<?php require_once __DIR__.'/../includes/functions.php';require_role('tutor');redirect('bookings.php?status=pending');
