<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_login(); refresh_session_user($conn);
$uid = user_id();
$stats = [];
if (role() === 'learner') {
    $stmt=$conn->prepare("SELECT COUNT(*) total, SUM(status='pending') pending, SUM(status='accepted') accepted, SUM(status='completed') completed FROM bookings WHERE learner_id=?");
    $stmt->bind_param('i',$uid);$stmt->execute();$stats=$stmt->get_result()->fetch_assoc();
} elseif (role() === 'tutor') {
    $stmt=$conn->prepare("SELECT COUNT(DISTINCT l.id) listings, COUNT(DISTINCT b.id) requests, SUM(b.status='pending') pending, SUM(b.status='completed') completed FROM tutor_listings l LEFT JOIN bookings b ON b.listing_id=l.id WHERE l.tutor_id=?");
    $stmt->bind_param('i',$uid);$stmt->execute();$stats=$stmt->get_result()->fetch_assoc();
} else {
    $stats['users']=$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
    $stats['listings']=$conn->query("SELECT COUNT(*) c FROM tutor_listings")->fetch_assoc()['c'];
    $stats['bookings']=$conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'];
    $stats['reviews']=$conn->query("SELECT COUNT(*) c FROM reviews")->fetch_assoc()['c'];
}
$stmt=$conn->prepare('SELECT id,message,is_read,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 5');$stmt->bind_param('i',$uid);$stmt->execute();$notifications=$stmt->get_result();
$page_title='Dashboard';require __DIR__.'/includes/header.php';
?>
<section class="page-banner"><div class="container"><h1 class="h2 section-title">Welcome, <?= e(user()['full_name']) ?></h1><p class="mb-0 text-capitalize"><?= e(role()) ?> dashboard</p></div></section>
<div class="container py-5"><?php display_flashes(); ?>
<div class="row g-4 mb-4">
<?php foreach ($stats as $label=>$value): ?><div class="col-6 col-lg-3"><div class="card dashboard-card p-4 h-100"><div class="text-muted text-capitalize"><?= e(str_replace('_',' ',$label)) ?></div><div class="display-6 fw-bold section-title"><?= (int)$value ?></div></div></div><?php endforeach; ?>
</div>
<div class="row g-4">
<div class="col-lg-8"><div class="card dashboard-card p-4"><h4 class="section-title">Quick actions</h4><div class="d-flex flex-wrap gap-2 mt-3">
<a class="btn btn-gold" href="<?= url('tutors.php') ?>">Find tutors</a><a class="btn btn-outline-secondary" href="<?= url('bookings.php') ?>">My bookings</a>
<?php if(role()==='tutor'):?><a class="btn btn-outline-secondary" href="<?= url('tutor/listing_form.php') ?>">Create listing</a><a class="btn btn-outline-secondary" href="<?= url('tutor/requests.php') ?>">Manage requests</a><?php endif;?>
<?php if(role()==='admin'):?><a class="btn btn-outline-secondary" href="<?= url('admin/index.php') ?>">Open admin dashboard</a><?php endif;?>
</div></div></div>
<div class="col-lg-4"><div class="card dashboard-card p-4"><h4 class="section-title">Recent notifications</h4><?php if($notifications->num_rows):while($n=$notifications->fetch_assoc()):?><div class="border-bottom py-2"><small><?= e($n['message']) ?></small><br><span class="text-muted small"><?= e($n['created_at']) ?></span></div><?php endwhile;else:?><p class="text-muted mb-0">No notifications yet.</p><?php endif;?></div></div>
</div></div>
<button id="chatLaunch" class="btn btn-gold chat-launch shadow" title="Virtual Assistant"><i class="bi bi-chat-dots fs-4"></i></button>
<div id="chatPanel" class="card chat-panel shadow-lg"><div class="card-body"><h5 class="section-title">Tutor Assistant</h5><p class="small text-muted">Ask for a subject or skill, for example: “I need Java help online”.</p><form id="chatForm" class="d-flex gap-2"><input id="chatQuery" class="form-control" placeholder="Type a subject..."><button class="btn btn-gold">Search</button></form><div id="chatResults" class="chat-results mt-3"></div></div></div>
<?php require __DIR__.'/includes/footer.php';?>
