</main>
<footer class="footer mt-5 py-4">
  <div class="container d-flex flex-column flex-md-row justify-content-between gap-2">
    <div><strong>UTM Peer Tutoring & Skill Exchange Assistant</strong><br><small>SECV2223 Web Programming Final Project</small></div>
    <small>Group 8 - Cybernetics &copy; <?= date('Y') ?></small>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>window.APP_BASE_URL = <?= json_encode(BASE_URL) ?>;</script>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
