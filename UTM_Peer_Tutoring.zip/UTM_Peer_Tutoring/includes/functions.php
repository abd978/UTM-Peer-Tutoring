<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/config.php';

function url(string $path = ''): string {
    return BASE_URL . ($path ? '/' . ltrim($path, '/') : '');
}
function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
function is_post(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
function old(string $key, string $default = ''): string { return e($_POST[$key] ?? $default); }
function flash(string $type, string $message): void { $_SESSION['flash'][] = compact('type', 'message'); }
function display_flashes(): void {
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    foreach ($items as $item) {
        echo '<div class="alert alert-' . e($item['type']) . ' alert-dismissible fade show" role="alert">' . e($item['message']) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Invalid request token. Please return to the previous page and try again.');
    }
}
function logged_in(): bool { return !empty($_SESSION['user']); }
function user(): ?array { return $_SESSION['user'] ?? null; }
function user_id(): int { return (int)($_SESSION['user']['id'] ?? 0); }
function role(): string { return $_SESSION['user']['role'] ?? 'guest'; }
function require_login(): void { if (!logged_in()) { flash('warning', 'Please log in first.'); redirect('login.php'); } }
function require_role(array|string $roles): void {
    require_login();
    $roles = (array)$roles;
    if (!in_array(role(), $roles, true)) { http_response_code(403); exit('You are not allowed to open this page.'); }
}
function refresh_session_user(mysqli $conn): void {
    if (!logged_in()) return;
    $stmt = $conn->prepare('SELECT id, full_name, email, role, bio, phone, active FROM users WHERE id=?');
    $id = user_id(); $stmt->bind_param('i', $id); $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    if (!$result || !(int)$result['active']) { session_destroy(); redirect('login.php'); }
    $_SESSION['user'] = $result;
}
function notify_user(mysqli $conn, int $uid, string $message): void {
    $stmt = $conn->prepare('INSERT INTO notifications (user_id, message) VALUES (?, ?)');
    $stmt->bind_param('is', $uid, $message); $stmt->execute();
}
function stars(float $rating): string {
    $rounded = (int)round($rating);
    return str_repeat('★', $rounded) . str_repeat('☆', 5 - $rounded);
}
function format_money(float|string $amount): string { return 'RM ' . number_format((float)$amount, 2); }
function badge_class(string $status): string {
    return match ($status) {
        'accepted', 'completed', 'active' => 'success',
        'pending' => 'warning',
        'rejected', 'cancelled', 'inactive' => 'danger',
        default => 'secondary'
    };
}
function google_calendar_url(array $booking): string {
    $start = gmdate('Ymd\\THis\\Z', strtotime($booking['session_date']));
    $end = gmdate('Ymd\\THis\\Z', strtotime($booking['session_date']) + ((int)$booking['duration_minutes'] * 60));
    $params = [
        'action' => 'TEMPLATE',
        'text' => 'UTM Peer Tutoring - ' . $booking['subject_name'],
        'dates' => $start . '/' . $end,
        'details' => 'Tutoring session with ' . $booking['other_name'] . '. Mode: ' . $booking['session_mode'],
        'location' => $booking['location_or_link'] ?: 'To be confirmed'
    ];
    return 'https://calendar.google.com/calendar/render?' . http_build_query($params);
}
