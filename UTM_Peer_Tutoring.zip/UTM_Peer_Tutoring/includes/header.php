<?php
require_once __DIR__ . '/functions.php';
$page_title = $page_title ?? APP_NAME;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($page_title) ?> | <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= url('index.php') ?>"><span class="brand-box">UTM</span> Peer Tutor</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
        <li class="nav-item"><a class="nav-link" href="<?= url('index.php') ?>">Home</a></li>
        <?php if (logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="<?= url('dashboard.php') ?>">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= url('tutors.php') ?>">Find Tutors</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= url('bookings.php') ?>">Bookings</a></li>
          <?php if (role() === 'tutor'): ?><li class="nav-item"><a class="nav-link" href="<?= url('tutor/listings.php') ?>">My Listings</a></li><?php endif; ?>
          <?php if (role() === 'admin'): ?><li class="nav-item"><a class="nav-link" href="<?= url('admin/index.php') ?>">Admin</a></li><?php endif; ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><?= e(user()['full_name'] ?? 'Account') ?></a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="<?= url('profile.php') ?>">Profile</a></li>
              <li><a class="dropdown-item" href="<?= url('change_password.php') ?>">Change password</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= url('logout.php') ?>">Logout</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= url('login.php') ?>">Login</a></li>
          <li class="nav-item"><a class="btn btn-gold ms-lg-2" href="<?= url('register.php') ?>">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main>
