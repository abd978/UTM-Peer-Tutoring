<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <span class="badge text-bg-warning text-dark mb-3">Built for UTM students</span>
        <h1 class="display-4 fw-bold">Find help. Share skills. Learn together.</h1>
        <p class="lead mt-3">A student platform to search trusted peer tutors, compare availability and prices, send booking requests, attend sessions, and share reviews.</p>
        <div class="d-flex flex-wrap gap-2 mt-4">
          <a href="<?= url(logged_in() ? 'tutors.php' : 'register.php') ?>" class="btn btn-gold btn-lg">Find a Tutor</a>
          <a href="<?= url(logged_in() ? 'tutor/listings.php' : 'register.php') ?>" class="btn btn-outline-light btn-lg">Become a Tutor</a>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="card border-0 shadow-lg rounded-4 p-4 text-dark">
          <h4 class="section-title">Simple booking flow</h4>
          <ol class="mb-0 mt-3">
            <li class="mb-2">Create a learner or tutor account.</li>
            <li class="mb-2">Search by subject, skill, mode, or price.</li>
            <li class="mb-2">Send and manage a booking request.</li>
            <li>Complete the session and leave a rating.</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="py-5">
  <div class="container">
    <div class="text-center mb-5"><h2 class="section-title">What the system provides</h2><p class="text-muted">One organized place for peer learning.</p></div>
    <div class="row g-4">
      <?php foreach ([
        ['bi-search','Search and filter','Find tutors by subject, skill, session mode, rating, and price.'],
        ['bi-calendar-check','Booking management','Request, accept, reject, cancel, and complete tutoring sessions.'],
        ['bi-star','Ratings and reviews','Share feedback after completed sessions and build tutor reputation.'],
        ['bi-shield-check','Secure accounts','Passwords are hashed and every user only manages their own records.']
      ] as $f): ?>
      <div class="col-md-6 col-lg-3"><div class="card feature-card h-100 p-4"><div class="icon-circle mb-3"><i class="bi <?= $f[0] ?>"></i></div><h5><?= e($f[1]) ?></h5><p class="text-muted mb-0"><?= e($f[2]) ?></p></div></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
