CREATE DATABASE IF NOT EXISTS utm_peer_tutoring CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE utm_peer_tutoring;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS tutor_listings;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('learner','tutor','admin') NOT NULL DEFAULT 'learner',
  bio TEXT NULL,
  phone VARCHAR(30) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  category VARCHAR(80) NOT NULL DEFAULT 'Academic',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tutor_listings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tutor_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  price_per_hour DECIMAL(8,2) NOT NULL DEFAULT 0,
  mode ENUM('online','face_to_face','either') NOT NULL DEFAULT 'either',
  location VARCHAR(180) NULL,
  availability_text VARCHAR(255) NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_listing_tutor FOREIGN KEY (tutor_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_listing_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE RESTRICT,
  INDEX idx_listing_filter (subject_id, mode, status, price_per_hour)
) ENGINE=InnoDB;

CREATE TABLE bookings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  learner_id INT UNSIGNED NOT NULL,
  listing_id INT UNSIGNED NOT NULL,
  session_date DATETIME NOT NULL,
  duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 60,
  session_mode ENUM('online','face_to_face') NOT NULL,
  location_or_link VARCHAR(255) NULL,
  message VARCHAR(500) NULL,
  status ENUM('pending','accepted','rejected','cancelled','completed') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_learner FOREIGN KEY (learner_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_booking_listing FOREIGN KEY (listing_id) REFERENCES tutor_listings(id) ON DELETE RESTRICT,
  INDEX idx_booking_status_date (status, session_date)
) ENGINE=InnoDB;

CREATE TABLE reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_id INT UNSIGNED NOT NULL UNIQUE,
  learner_id INT UNSIGNED NOT NULL,
  tutor_id INT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(1000) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_review_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_review_learner FOREIGN KEY (learner_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_review_tutor FOREIGN KEY (tutor_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  message VARCHAR(255) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notification_user (user_id, is_read, created_at)
) ENGINE=InnoDB;

INSERT INTO subjects (name,category) VALUES
('Web Programming','Academic'),('Java Programming','Academic'),('Object-Oriented Programming','Academic'),('Computer Networks','Academic'),('Computer Security','Academic'),('Database Systems','Academic'),('Mathematics','Academic'),('Academic Writing','Academic'),('Graphic Design','Practical Skill'),('Presentation Skills','Practical Skill');

-- Demo password for all demo accounts: Student123!
INSERT INTO users (full_name,email,password_hash,role,bio,phone) VALUES
('System Administrator','admin@utm.my','$2y$12$uGJVRNnTKmUKVleR6eO/SObh/BicJuVXXevYuQufTEnAGQNGnnBnO','admin','Project administrator account',''),
('Aiman Hakim','aiman@graduate.utm.my','$2y$12$uGJVRNnTKmUKVleR6eO/SObh/BicJuVXXevYuQufTEnAGQNGnnBnO','tutor','Computer science student who enjoys helping juniors with Java and web development.','0123456789'),
('Nur Aisyah','aisyah@graduate.utm.my','$2y$12$uGJVRNnTKmUKVleR6eO/SObh/BicJuVXXevYuQufTEnAGQNGnnBnO','tutor','Final-year student offering mathematics and academic writing support.','0112233445'),
('Demo Learner','learner@graduate.utm.my','$2y$12$uGJVRNnTKmUKVleR6eO/SObh/BicJuVXXevYuQufTEnAGQNGnnBnO','learner','Learner demo account','0198765432');

INSERT INTO tutor_listings (tutor_id,subject_id,title,description,price_per_hour,mode,location,availability_text) VALUES
(2,2,'Java Programming Support','Step-by-step help with Java basics, classes, inheritance, arrays, and small OOP exercises.',15.00,'either','UTM Library or Google Meet','Sunday to Thursday, 7:00 PM - 10:00 PM'),
(2,1,'Web Programming Practice','Practical support for HTML, CSS, JavaScript, PHP, forms, and MySQL CRUD activities.',18.00,'online','Google Meet','Monday, Wednesday, and Thursday evenings'),
(3,7,'Mathematics Peer Tutoring','Friendly explanations and guided practice for common university mathematics topics.',12.00,'face_to_face','UTM Library','Tuesday and Thursday, 4:00 PM - 7:00 PM'),
(3,8,'Academic Writing Review','Help with paragraph organization, grammar, citations, and presentation scripts.',10.00,'either','UTM Library or Microsoft Teams','Weekends and selected evenings');

INSERT INTO bookings (learner_id,listing_id,session_date,duration_minutes,session_mode,location_or_link,message,status) VALUES
(4,1,'2026-06-20 20:00:00',60,'online','Google Meet','Need help with inheritance and interfaces.','completed'),
(4,3,'2026-06-22 17:00:00',60,'face_to_face','UTM Library','Need practice for calculus tutorial.','completed');

INSERT INTO reviews (booking_id,learner_id,tutor_id,rating,comment) VALUES
(1,4,2,5,'Clear explanation and useful Java examples. The tutor was patient and prepared.'),
(2,4,3,4,'Helpful session and good practice questions. The meeting started on time.');

INSERT INTO notifications (user_id,message) VALUES
(2,'A learner submitted a review for Java Programming Support.'),
(3,'A learner submitted a review for Mathematics Peer Tutoring.'),
(4,'Your completed sessions are ready for review.');
