<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
if (logged_in()) redirect('dashboard.php');
$error = '';
if (is_post()) {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare('SELECT id, full_name, email, password_hash, role, bio, phone, active FROM users WHERE email=?');
    $stmt->bind_param('s', $email); $stmt->execute(); $account = $stmt->get_result()->fetch_assoc();
    if ($account && (int)$account['active'] === 1 && password_verify($password, $account['password_hash'])) {
        unset($account['password_hash']); session_regenerate_id(true); $_SESSION['user'] = $account;
        flash('success', 'Welcome back, ' . $account['full_name'] . '.'); redirect('dashboard.php');
    }
    $error = 'Invalid email or password, or the account is inactive.';
}
$page_title = 'Login'; require __DIR__ . '/includes/header.php';
?>
<section class="page-banner"><div class="container"><h1 class="h2 section-title">Login</h1><p class="mb-0">Access your learner, tutor, or administrator dashboard.</p></div></section>
<div class="container py-5"><div class="card form-card p-4 p-md-5" style="max-width:580px">
<?php display_flashes(); if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="needs-validation" novalidate><?= csrf_field() ?>
<div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= old('email') ?>" required></div>
<div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
<button class="btn btn-gold w-100">Login</button></form>
<p class="text-center mt-3 mb-0">New user? <a href="<?= url('register.php') ?>">Create an account</a></p>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
