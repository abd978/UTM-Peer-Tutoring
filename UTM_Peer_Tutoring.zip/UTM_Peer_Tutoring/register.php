<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
if (logged_in()) redirect('dashboard.php');
$errors = [];
if (is_post()) {
    verify_csrf();
    $name = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $roleInput = $_POST['role'] ?? '';
    if (strlen($name) < 3) $errors[] = 'Full name must contain at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!preg_match('/@([a-z0-9-]+\.)*utm\.my$/i', $email)) $errors[] = 'Please use a valid UTM email address.';
    if (strlen($password) < 8) $errors[] = 'Password must contain at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Password confirmation does not match.';
    if (!in_array($roleInput, ['learner','tutor'], true)) $errors[] = 'Select learner or tutor.';
    if (!$errors) {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email=?'); $stmt->bind_param('s', $email); $stmt->execute();
        if ($stmt->get_result()->num_rows) $errors[] = 'An account already exists with this email.';
    }
    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)');
        $stmt->bind_param('ssss', $name, $email, $hash, $roleInput);
        if ($stmt->execute()) { flash('success', 'Account created successfully. You can now log in.'); redirect('login.php'); }
        $errors[] = 'Registration failed. Please try again.';
    }
}
$page_title = 'Register'; require __DIR__ . '/includes/header.php';
?>
<section class="page-banner"><div class="container"><h1 class="h2 section-title">Create an account</h1><p class="mb-0">Register as a learner or tutor using your UTM email.</p></div></section>
<div class="container py-5"><div class="card form-card p-4 p-md-5">
<?php foreach ($errors as $error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endforeach; ?>
<form method="post" class="needs-validation" novalidate>
<?= csrf_field() ?>
<div class="row g-3">
<div class="col-12"><label class="form-label">Full name</label><input class="form-control" name="full_name" value="<?= old('full_name') ?>" minlength="3" required><div class="invalid-feedback">Enter your full name.</div></div>
<div class="col-12"><label class="form-label">UTM email</label><input type="email" class="form-control" name="email" value="<?= old('email') ?>" placeholder="name@graduate.utm.my" required></div>
<div class="col-md-6"><label class="form-label">Password</label><input type="password" class="form-control" name="password" minlength="8" required></div>
<div class="col-md-6"><label class="form-label">Confirm password</label><input type="password" class="form-control" name="confirm_password" minlength="8" required></div>
<div class="col-12"><label class="form-label">Main role</label><select class="form-select" name="role" required><option value="">Select role</option><option value="learner" <?= old('role')==='learner'?'selected':'' ?>>Learner</option><option value="tutor" <?= old('role')==='tutor'?'selected':'' ?>>Tutor</option></select></div>
<div class="col-12"><button class="btn btn-gold w-100">Create Account</button></div>
</div></form>
<p class="text-center mt-3 mb-0">Already registered? <a href="<?= url('login.php') ?>">Login</a></p>
</div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
