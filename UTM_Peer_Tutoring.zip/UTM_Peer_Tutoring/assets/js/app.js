document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      if (!confirm(form.dataset.confirm || 'Are you sure?')) event.preventDefault();
    });
  });

  document.querySelectorAll('form.needs-validation').forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  const launch = document.querySelector('#chatLaunch');
  const panel = document.querySelector('#chatPanel');
  if (launch && panel) launch.addEventListener('click', () => panel.classList.toggle('open'));

  const chatForm = document.querySelector('#chatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', async event => {
      event.preventDefault();
      const input = document.querySelector('#chatQuery');
      const results = document.querySelector('#chatResults');
      const q = input.value.trim();
      if (!q) return;
      results.innerHTML = '<div class="text-muted">Searching available tutors...</div>';
      try {
        const response = await fetch(`${window.APP_BASE_URL}/api/chatbot.php?q=${encodeURIComponent(q)}`);
        const data = await response.json();
        if (!data.length) {
          results.innerHTML = '<div class="alert alert-light mb-0">No exact match. Try a subject such as Java, Mathematics, or Web Programming.</div>';
          return;
        }
        results.innerHTML = data.map(item => `<a class="d-block text-decoration-none border rounded p-2 mb-2" href="${window.APP_BASE_URL}/tutor_view.php?id=${item.id}"><strong>${escapeHtml(item.title)}</strong><br><small>${escapeHtml(item.subject_name)} - ${escapeHtml(item.tutor_name)} - RM ${item.price_per_hour}/h</small></a>`).join('');
      } catch (error) {
        results.innerHTML = '<div class="alert alert-danger mb-0">The assistant could not load recommendations.</div>';
      }
    });
  }
});
function escapeHtml(value) {
  const div = document.createElement('div'); div.textContent = value; return div.innerHTML;
}
