<?php
// Basic project settings. Edit BASE_URL if the project folder name changes.
define('APP_NAME', 'UTM Peer Tutoring');
define('BASE_URL', '/UTM_Peer_Tutoring');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'utm_peer_tutoring');
date_default_timezone_set('Asia/Kuala_Lumpur');
