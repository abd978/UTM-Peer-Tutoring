<?php
require_once __DIR__.'/config/database.php';require_once __DIR__.'/includes/functions.php';require_role('learner');if(!is_post())redirect('tutors.php');verify_csrf();
$listingId=(int)($_POST['listing_id']??0);$date=$_POST['session_date']??'';$duration=(int)($_POST['duration_minutes']??60);$mode=$_POST['session_mode']??'';$message=trim($_POST['message']??'');
$stmt=$conn->prepare("SELECT l.id,l.tutor_id,l.mode,l.title,u.full_name tutor_name FROM tutor_listings l JOIN users u ON u.id=l.tutor_id WHERE l.id=? AND l.status='active'");$stmt->bind_param('i',$listingId);$stmt->execute();$listing=$stmt->get_result()->fetch_assoc();
if(!$listing){flash('danger','The listing is no longer available.');redirect('tutors.php');}
$allowedModes=$listing['mode']==='either'?['online','face_to_face']:[$listing['mode']];
if(strtotime($date)<=time()){flash('danger','Choose a future date and time.');redirect('tutor_view.php?id='.$listingId);}if(!in_array($duration,[60,90,120],true)||!in_array($mode,$allowedModes,true)){flash('danger','Invalid booking information.');redirect('tutor_view.php?id='.$listingId);}
$stmt=$conn->prepare('INSERT INTO bookings (learner_id,listing_id,session_date,duration_minutes,session_mode,message) VALUES (?,?,?,?,?,?)');$uid=user_id();$stmt->bind_param('iisiss',$uid,$listingId,$date,$duration,$mode,$message);$stmt->execute();notify_user($conn,(int)$listing['tutor_id'],'New booking request for '.$listing['title'].'.');flash('success','Booking request sent to '.$listing['tutor_name'].'.');redirect('bookings.php');
