<?php
require_once __DIR__.'/config/database.php';require_once __DIR__.'/includes/functions.php';require_login();if(!is_post())redirect('bookings.php');verify_csrf();$id=(int)($_POST['id']??0);$action=$_POST['action']??'';
$stmt=$conn->prepare("SELECT b.*,l.tutor_id,l.title FROM bookings b JOIN tutor_listings l ON l.id=b.listing_id WHERE b.id=?");$stmt->bind_param('i',$id);$stmt->execute();$b=$stmt->get_result()->fetch_assoc();if(!$b){flash('danger','Booking not found.');redirect('bookings.php');}
$new='';$recipient=0;$message='';
if(role()==='tutor'&&user_id()===(int)$b['tutor_id']&&$b['status']==='pending'&&in_array($action,['accept','reject'])){$new=$action==='accept'?'accepted':'rejected';$recipient=(int)$b['learner_id'];$message='Your booking request for '.$b['title'].' was '.$new.'.';}
elseif(role()==='learner'&&user_id()===(int)$b['learner_id']&&in_array($b['status'],['pending','accepted'])&&$action==='cancel'){$new='cancelled';$recipient=(int)$b['tutor_id'];$message='A learner cancelled the booking for '.$b['title'].'.';}
elseif(in_array(role(),['learner','tutor'])&&($uid=user_id())&&( $uid===(int)$b['learner_id']||$uid===(int)$b['tutor_id'])&&$b['status']==='accepted'&&$action==='complete'){$new='completed';$recipient=$uid===(int)$b['learner_id']?(int)$b['tutor_id']:(int)$b['learner_id'];$message='The tutoring session for '.$b['title'].' was marked completed.';}
if(!$new){flash('danger','This action is not allowed for the current booking status.');redirect('bookings.php');}
$stmt=$conn->prepare('UPDATE bookings SET status=? WHERE id=?');$stmt->bind_param('si',$new,$id);$stmt->execute();notify_user($conn,$recipient,$message);flash('success','Booking status updated to '.$new.'.');redirect('bookings.php');
